@javax.xml.bind.annotation.XmlSchema(namespace = "http://services/")
package upper_case_client;
